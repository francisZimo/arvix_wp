<!DOCTYPE html>
<html>
<head lang="en">
    <meta charset="UTF-8">
    <title></title>
    <link rel="stylesheet" href="<?php bloginfo('template_url');?>/css/reset.css"/>
    <link rel="stylesheet" href="<?php bloginfo('template_url');?>/css/index.css">
    <script src="<?php bloginfo('template_url');?>/jq/jquery.min.js"></script>
    <script src="<?php bloginfo('template_url');?>/js/page.js"></script>
    <?php wp_head()?>
</head>
<body <?php body_class();?>>
